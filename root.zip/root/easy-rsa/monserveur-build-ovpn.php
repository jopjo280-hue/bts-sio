#!/usr/bin/php
<?php
exec("pwd",$pwd);
$pwd=$pwd[0];

# Nom du certificat
if($argv[1] != ""){
  $user=$argv[1];
}else{
  exec("ls",$tmp);
  foreach($tmp as $item){
    $t=explode('.',$item);
    if(count($t)>=2 && $t[1]=="key" && $t[0]!="ta"){
      $user=$t[0];
    }
  }
}
echo "Création de $user.ovpn\n";

# Nettoyage
exec("rm $pwd/$user.ovpn 2> /dev/null");

# Fichiers de configuration

if(file_exists("$pwd/client.conf")){
  $tmp=file("$pwd/client.conf");
  foreach($tmp as $item){
    $item=trim($item);
    if(stripos($item,"/etc/openvpn/ca.crt")){
      exec("echo \"ca [inline]\" >> $pwd/$user.ovpn");
    }
    elseif(stripos($item,"/etc/openvpn/$user.crt")){
      exec("echo \"cert [inline]\" >> $pwd/$user.ovpn");
    }
    elseif(stripos($item,"/etc/openvpn/$user.key")){
      exec("echo \"key [inline]\" >> $pwd/$user.ovpn");
    }
    elseif(stripos($item,"/etc/openvpn/ta.key")){
      exec("echo \"tls-auth [inline] 1\" >> $pwd/$user.ovpn");
    }
    else{
      exec("echo \"$item\" >> $pwd/$user.ovpn");
    }
  }
}else{
  echo "ERREUR : Il n'y a pas de fichier client.conf\n";
}

if(file_exists("$pwd/ca.crt")){
  exec("echo \"\" >> $pwd/$user.ovpn");
  exec("echo \"<ca>\" >> $pwd/$user.ovpn");
  $tmp=file("$pwd/ca.crt");
  foreach($tmp as $item){
    $item=trim($item);
    exec("echo \"$item\" >> $pwd/$user.ovpn");
  }
  exec("echo \"</ca>\" >> $pwd/$user.ovpn");
}else{
  echo "ERREUR : Il n'y a pas de fichier ca.crt\n";
}

if(file_exists("$pwd/$user.crt")){
  exec("echo \"\" >> $pwd/$user.ovpn");
  exec("echo \"<cert>\" >> $pwd/$user.ovpn");
  $tmp=file("$pwd/$user.crt");
  $write='no';
  foreach($tmp as $item){
    $item=trim($item);
    if(stripos($item,"---BEGIN CERTIFICATE---")){
      $write='yes';
    }
    if($write=='yes' && $item!=""){
      exec("echo \"$item\" >> $pwd/$user.ovpn");
    }
    if(stripos($item,"---END CERTIFICATE---")){
      $write='no';
    }
  }
  exec("echo \"</cert>\" >> $pwd/$user.ovpn");
}else{
  echo "ERREUR : Il n'y a pas de fichier $user.crt\n";
}

if(file_exists("$pwd/$user.key")){
  exec("echo \"\" >> $pwd/$user.ovpn");
  exec("echo \"<key>\" >> $pwd/$user.ovpn");
  $tmp=file("$pwd/$user.key");
  foreach($tmp as $item){
    $item=trim($item);
    exec("echo \"$item\" >> $pwd/$user.ovpn");
  }
  exec("echo \"</key>\" >> $pwd/$user.ovpn");
}else{
  echo "ERREUR : Il n'y a pas de fichier $user.key\n";
}

if(file_exists("$pwd/ta.key")){
  exec("echo \"\" >> $pwd/$user.ovpn");
  exec("echo \"<tls-auth>\" >> $pwd/$user.ovpn");
  $tmp=file("$pwd/ta.key");
  $write='no';
  foreach($tmp as $item){
    $item=trim($item);
    if(stripos($item,"---BEGIN OpenVPN Static key V1---")){
      $write='yes';
    }
    if($write=='yes' && $item!=""){
      exec("echo \"$item\" >> $pwd/$user.ovpn");
    }
    if(stripos($item,"---END OpenVPN Static key V1---")){
      $write='no';
    }
  }
  exec("echo \"</tls-auth>\" >> $pwd/$user.ovpn");
}else{
  echo "ERREUR : Il n'y a pas de fichier ta.key\n";
}

exec("chmod 600 $pwd/$user.ovpn 2> /dev/null");
?>
